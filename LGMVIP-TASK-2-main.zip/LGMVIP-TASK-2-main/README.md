# LGMVIP-TASK-2
WEB DEVELPMENT VIRTUAL INTERNSHIP PROGRAM BY LETS GROW MORE

Task 2 -Web application using Create-react-app

To Run the App steps:

Clone the Repository

Open Terminal and run Command "npm start"
